#include "termux_ahb_bridge.h"

#ifdef TERMUX_AHB

#include <android/hardware_buffer.h>
#include <EGL/eglext.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <X11/Xlib-xcb.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <unistd.h>
#include <xcb/dri3.h>
#include <xcb/present.h>
#include <xcb/xcb.h>

#ifndef AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM
#define AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM 1
#endif
#ifndef AHARDWAREBUFFER_FORMAT_R8G8B8X8_UNORM
#define AHARDWAREBUFFER_FORMAT_R8G8B8X8_UNORM 2
#endif
#ifndef AHARDWAREBUFFER_FORMAT_B8G8R8A8_UNORM
#define AHARDWAREBUFFER_FORMAT_B8G8R8A8_UNORM 5
#endif

typedef EGLClientBuffer(EGLAPIENTRYP get_native_client_buffer_proc)(
    const AHardwareBuffer *buffer);

struct termux_ahb_api {
    void *library;
    int (*allocate)(const AHardwareBuffer_Desc *, AHardwareBuffer **);
    void (*describe)(const AHardwareBuffer *, AHardwareBuffer_Desc *);
    void (*release)(AHardwareBuffer *);
    int (*send_handle)(const AHardwareBuffer *, int);
};

struct termux_ahb_surface {
    Display *display;
    Drawable drawable;
    xcb_connection_t *connection;
    EGLDisplay egl_display;
    EGLSurface egl_surface;
    EGLContext egl_context;
    __eglMustCastToProperFunctionPointerType (*get_proc)(const char *);
    void *gles_library;
    AHardwareBuffer *buffer;
    EGLImageKHR image;
    GLuint texture;
    xcb_pixmap_t pixmap;
    int width;
    int height;
    uint32_t serial;
};

static struct termux_ahb_api android_api;
static struct termux_ahb_surface current = {
    .image = EGL_NO_IMAGE_KHR,
};

static void *
get_gl_proc(const char *name)
{
    void *proc = current.gles_library
        ? dlsym(current.gles_library, name)
        : NULL;
    if (proc)
        return proc;
    return current.get_proc
        ? (void *)(uintptr_t)current.get_proc(name)
        : NULL;
}

static int
load_android_api(void)
{
    if (android_api.library)
        return android_api.allocate && android_api.describe &&
               android_api.release && android_api.send_handle;

    android_api.library = dlopen("libandroid.so", RTLD_NOW | RTLD_LOCAL);
    if (!android_api.library)
        return 0;
    android_api.allocate = dlsym(android_api.library,
                                 "AHardwareBuffer_allocate");
    android_api.describe = dlsym(android_api.library,
                                 "AHardwareBuffer_describe");
    android_api.release = dlsym(android_api.library,
                                "AHardwareBuffer_release");
    android_api.send_handle = dlsym(
        android_api.library, "AHardwareBuffer_sendHandleToUnixSocket");
    return android_api.allocate && android_api.describe &&
           android_api.release && android_api.send_handle;
}

static void
destroy_buffer(void)
{
    PFNEGLDESTROYIMAGEKHRPROC destroy_image;
    PFNGLDELETETEXTURESPROC delete_textures;

    if (current.pixmap && current.connection) {
        xcb_free_pixmap(current.connection, current.pixmap);
        xcb_flush(current.connection);
        current.pixmap = 0;
    }
    if (current.image != EGL_NO_IMAGE_KHR && current.get_proc) {
        destroy_image = (PFNEGLDESTROYIMAGEKHRPROC)
            current.get_proc("eglDestroyImageKHR");
        if (destroy_image)
            destroy_image(current.egl_display, current.image);
        current.image = EGL_NO_IMAGE_KHR;
    }
    if (current.texture && current.get_proc) {
        delete_textures = (PFNGLDELETETEXTURESPROC)
            get_gl_proc("glDeleteTextures");
        if (delete_textures)
            delete_textures(1, &current.texture);
        current.texture = 0;
    }
    if (current.buffer) {
        android_api.release(current.buffer);
        current.buffer = NULL;
    }
    current.width = 0;
    current.height = 0;
}

void
termux_ahb_set_drawable(Display *display, Drawable drawable,
                        EGLDisplay egl_display, EGLSurface egl_surface,
                        EGLContext egl_context,
                        __eglMustCastToProperFunctionPointerType (*get_proc)(const char *),
                        void *gles_library)
{
    if (current.drawable != drawable || current.display != display)
        destroy_buffer();

    current.display = display;
    current.drawable = drawable;
    current.connection = XGetXCBConnection(display);
    current.egl_display = egl_display;
    current.egl_surface = egl_surface;
    current.egl_context = egl_context;
    current.get_proc = get_proc;
    current.gles_library = gles_library;
}

static int
check_xcb(xcb_void_cookie_t cookie, const char *operation)
{
    xcb_generic_error_t *error = xcb_request_check(current.connection, cookie);
    if (!error)
        return 1;
    fprintf(stderr, "LIBGL: Termux AHB %s failed: X11 error %u\n",
            operation, error->error_code);
    free(error);
    return 0;
}

int
termux_ahb_prepare_current(int width, int height, unsigned int *texture)
{
    AHardwareBuffer_Desc description = {0};
    get_native_client_buffer_proc get_native_client_buffer;
    PFNEGLCREATEIMAGEKHRPROC create_image;
    PFNEGLMAKECURRENTPROC make_current;
    PFNGLGENTEXTURESPROC gen_textures;
    PFNGLBINDTEXTUREPROC bind_texture;
    PFNGLTEXPARAMETERIPROC tex_parameteri;
    PFNGLEGLIMAGETARGETTEXTURE2DOESPROC image_target_texture;
    PFNGLGETERRORPROC get_error;
    EGLClientBuffer egl_buffer;
    if (!texture || width <= 0 || height <= 0 || !current.connection ||
        !current.get_proc || !load_android_api())
        return 0;
    if (current.buffer && current.width == width && current.height == height) {
        *texture = current.texture;
        return 1;
    }

    destroy_buffer();
    description.width = width;
    description.height = height;
    description.layers = 1;
    /* Xwayland marks depth-24 buffers opaque in the private Wayland protocol;
     * alpha written by desktop GL is otherwise undefined. */
    description.format = AHARDWAREBUFFER_FORMAT_B8G8R8A8_UNORM;
    description.usage = AHARDWAREBUFFER_USAGE_GPU_FRAMEBUFFER |
                        AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE;
    if (android_api.allocate(&description, &current.buffer) != 0)
        goto error;
    android_api.describe(current.buffer, &description);

    get_native_client_buffer = (get_native_client_buffer_proc)
        current.get_proc("eglGetNativeClientBufferANDROID");
    create_image = (PFNEGLCREATEIMAGEKHRPROC)
        current.get_proc("eglCreateImageKHR");
    make_current = (PFNEGLMAKECURRENTPROC)
        current.get_proc("eglMakeCurrent");
    gen_textures = (PFNGLGENTEXTURESPROC)get_gl_proc("glGenTextures");
    bind_texture = (PFNGLBINDTEXTUREPROC)get_gl_proc("glBindTexture");
    tex_parameteri = (PFNGLTEXPARAMETERIPROC)get_gl_proc("glTexParameteri");
    image_target_texture = (PFNGLEGLIMAGETARGETTEXTURE2DOESPROC)
        get_gl_proc("glEGLImageTargetTexture2DOES");
    get_error = (PFNGLGETERRORPROC)get_gl_proc("glGetError");
    if (!get_native_client_buffer || !create_image || !make_current ||
        !gen_textures || !bind_texture || !tex_parameteri ||
        !image_target_texture || !get_error)
        goto error;

    if (!make_current(current.egl_display, current.egl_surface,
                      current.egl_surface, current.egl_context))
        goto error;
    /* gfxstream requires a texture name before native-buffer import. */
    gen_textures(1, &current.texture);
    egl_buffer = get_native_client_buffer(current.buffer);
    current.image = create_image(
        current.egl_display, EGL_NO_CONTEXT, EGL_NATIVE_BUFFER_ANDROID,
        egl_buffer, (const EGLint[]){EGL_IMAGE_PRESERVED_KHR, EGL_TRUE,
                                    EGL_NONE});
    if (current.image == EGL_NO_IMAGE_KHR)
        goto error;
    if (!make_current(current.egl_display, current.egl_surface,
                      current.egl_surface, current.egl_context))
        goto error;

    bind_texture(GL_TEXTURE_2D, current.texture);
    tex_parameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    tex_parameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    tex_parameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    tex_parameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    while (get_error() != GL_NO_ERROR)
        ;
    image_target_texture(GL_TEXTURE_2D, current.image);
    if (get_error() != GL_NO_ERROR)
        goto error;

    current.width = width;
    current.height = height;
    *texture = current.texture;
    fprintf(stderr,
            "LIBGL: Termux AHB DRI3 surface %dx%d texture=%u format=%u, "
            "system GLES zero-copy\n",
            width, height, current.texture, description.format);
    return 1;

error:
    destroy_buffer();
    return 0;
}

static int
import_current_pixmap(void)
{
    AHardwareBuffer_Desc description = {0};
    int sockets[2] = {-1, -1};
    uint32_t dri3_stride;

    if (!current.buffer || !current.connection)
        return 0;
    android_api.describe(current.buffer, &description);
    if (socketpair(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0, sockets) != 0)
        goto error;
    if (android_api.send_handle(current.buffer, sockets[0]) != 0)
        goto error;

    XFlush(current.display);
    current.pixmap = xcb_generate_id(current.connection);
    dri3_stride = (description.stride ? description.stride : current.width) * 4;
    if (!check_xcb(xcb_dri3_pixmap_from_buffer_checked(
                       current.connection, current.pixmap, current.drawable,
                       dri3_stride * current.height, current.width,
                       current.height, dri3_stride,
                       DefaultDepth(current.display,
                                    DefaultScreen(current.display)),
                       32, sockets[1]),
                   "PixmapFromBuffer"))
        goto error;
    close(sockets[0]);
    sockets[0] = -1;
    sockets[1] = -1; /* ownership transferred to xcb */
    return 1;

error:
    if (sockets[0] >= 0)
        close(sockets[0]);
    if (sockets[1] >= 0)
        close(sockets[1]);
    if (current.pixmap) {
        xcb_free_pixmap(current.connection, current.pixmap);
        current.pixmap = 0;
    }
    return 0;
}

int
termux_ahb_present_current(void)
{
    PFNGLFINISHPROC finish;

    if (!current.connection || !current.get_proc)
        return 0;
    finish = (PFNGLFINISHPROC)get_gl_proc("glFinish");
    if (!finish)
        return 0;
    finish();

    /* gfxstream must observe completed rendering before another process
     * imports the AHardwareBuffer; importing the initial empty allocation
     * first can leave the consumer on a stale backing resource. */
    if (!current.pixmap && !import_current_pixmap())
        return 0;

    if (!check_xcb(xcb_present_pixmap_checked(
                       current.connection, current.drawable, current.pixmap,
                       ++current.serial, XCB_NONE, XCB_NONE, 0, 0, XCB_NONE,
                       XCB_NONE, XCB_NONE, 0, 0, 0, 0, 0, NULL),
                   "PresentPixmap"))
        return 0;
    xcb_flush(current.connection);
    return 1;
}

#endif

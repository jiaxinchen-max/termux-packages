#ifndef GL4ES_TERMUX_AHB_BRIDGE_H
#define GL4ES_TERMUX_AHB_BRIDGE_H

#ifdef TERMUX_AHB

#include <EGL/egl.h>
#include <X11/Xlib.h>

void termux_ahb_set_drawable(Display *display, Drawable drawable,
                             EGLDisplay egl_display, EGLSurface egl_surface,
                             EGLContext egl_context,
                             __eglMustCastToProperFunctionPointerType (*get_proc)(const char *),
                             void *gles_library);
int termux_ahb_prepare_current(int width, int height, unsigned int *texture);
int termux_ahb_present_current(void);

#else

#define termux_ahb_set_drawable(...) ((void)0)
#define termux_ahb_prepare_current(width, height, texture) 0
#define termux_ahb_present_current() 0

#endif

#endif
